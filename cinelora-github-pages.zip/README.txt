CineLora static website

Upload index.html to the root of a public GitHub repository, then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
This is a front-end demo with sample movie data and reviews. It does not host or stream movie files and does not yet have a database/admin panel.
